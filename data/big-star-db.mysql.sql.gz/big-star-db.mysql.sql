-- Converted for MySQL

CREATE TABLE customers (
    customer_id INT UNIQUE NOT NULL,
    first_name VARCHAR(255),
    last_name VARCHAR(255),
    email VARCHAR(255),
    gender VARCHAR(255),
    city VARCHAR(255),
    country CHAR(2),
    ip_address VARCHAR(15)
);

CREATE TABLE order_items (
    order_item_id INT UNIQUE NOT NULL,
    order_id INT,
    product_id INT,
    product_price numeric(10,2)
);

CREATE TABLE orders (
    order_id INT UNIQUE NOT NULL,
    customer_id INT,
    status VARCHAR(255),
    order_purchased_at timestamp,
    order_approved_at timestamp,
    order_delivered_at timestamp
);

CREATE TABLE products (
    product_id INT UNIQUE NOT NULL,
    name VARCHAR(255),
    category VARCHAR(255),
    collection VARCHAR(255),
    price numeric(10,2),
    rating numeric(3,1),
    availability boolean
);

LOAD DATA INFILE '/data/customers.csv'
INTO TABLE customers
FIELDS TERMINATED BY '\t'
LINES TERMINATED BY '\n'
IGNORE 1 LINES
(customer_id, first_name, last_name, email, gender, city, country, ip_address);

LOAD DATA INFILE '/data/order_items.csv'
INTO TABLE order_items
FIELDS TERMINATED BY '\t'
LINES TERMINATED BY '\n'
IGNORE 1 LINES
(order_item_id, order_id, product_id, product_price);

LOAD DATA INFILE '/data/orders.csv'
INTO TABLE orders
FIELDS TERMINATED BY '\t'
LINES TERMINATED BY '\n'
IGNORE 1 LINES
(order_id, customer_id, status, order_purchased_at, order_approved_at, order_delivered_at);

LOAD DATA INFILE '/data/products.csv'
INTO TABLE products
FIELDS TERMINATED BY '\t'
LINES TERMINATED BY '\n'
IGNORE 1 LINES
(product_id, name, category, collection, price, rating, availability);


-- Store and remove data to add inconsistencies (missing customers)
-- Note: This script avoids CTEs and LIMIT in subqueries to mimic one of my Prod DBs, which version does not support these features.

CREATE TEMPORARY TABLE tmp_customers_ids AS
SELECT customer_id FROM orders
GROUP BY customer_id HAVING COUNT(*) BETWEEN 5 AND 10
ORDER BY RAND() LIMIT 1000;

CREATE TABLE customers_delayed AS
SELECT c.* FROM customers c JOIN tmp_customers_ids t ON c.customer_id = t.customer_id;
ALTER TABLE customers_delayed ADD CONSTRAINT customers_delayed_key UNIQUE (customer_id);

DELETE FROM customers WHERE customer_id IN (SELECT customer_id FROM tmp_customers_ids);


-- Store and set data to add inconsistencies (missing products)

CREATE TEMPORARY TABLE tmp_products_ids AS
SELECT product_id FROM order_items
GROUP BY product_id HAVING COUNT(*) BETWEEN 75 AND 85
ORDER BY RAND() LIMIT 60;

CREATE TABLE products_delayed AS
SELECT p.* FROM products p JOIN tmp_products_ids t ON p.product_id = t.product_id;
ALTER TABLE products_delayed ADD CONSTRAINT products_delayed_key UNIQUE (product_id);

DELETE FROM products WHERE product_id IN (SELECT product_id FROM tmp_products_ids);

-- Store and set data to introduce inconsistencies (missing orders)

CREATE TEMPORARY TABLE tmp_orders_ids AS
SELECT DISTINCT order_id FROM order_items
ORDER BY RAND() LIMIT 1500;

CREATE TABLE orders_delayed AS
SELECT o.* FROM orders o JOIN tmp_orders_ids t ON o.order_id = t.order_id;
ALTER TABLE orders_delayed ADD CONSTRAINT orders_delayed_key UNIQUE (order_id);

DELETE FROM orders WHERE order_id IN (SELECT order_id FROM tmp_orders_ids);

